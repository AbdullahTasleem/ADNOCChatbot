A Pen created at CodePen.io. You can find this one at https://codepen.io/abdullahT/pen/yxJPRJ.

 inspired by https://www.intercom.com/

tried to add a floating chat button for support
